"""Patch 3: convert matrix_runner.py into the PDB2PQR protonation arm.

Arm 1 used PDBFixer for both missing heavy atoms and hydrogens, which is the
route the Module 7 baseline took. The course Software and Tools Guide labels
PDBFixer Optional and PDB2PQR with PROPKA Recommended, and states plainly that
PDBFixer hydrogens can make Meeko fail with a valence error - which is exactly
what happened, and what the OXT workaround in arm 1 papers over.

This arm therefore:
  * uses PDBFixer for missing heavy atoms ONLY,
  * protonates with PDB2PQR/PROPKA at pH 7.4 and takes its --pdb-output file,
  * records the titration state PROPKA assigned to every histidine (HID, HIE
    or HIP), which is what resolves the unaudited HIS114 chain B flag carried
    since Module 7,
  * leaves everything else - structures, superposition, box, ligands, seeds,
    exhaustiveness, RMSD convention - byte-identical to arm 1, so the two arms
    differ in protonation and nothing else.
"""

import re
import sys
from pathlib import Path

TARGET = Path(sys.argv[1] if len(sys.argv) > 1 else "/content/matrix_runner.py")
src = TARGET.read_text()

# ------------------------------------------------------------------ 1. prep
start = src.index("    fixer.addMissingAtoms()")
end = src.index("    prefix = WORK / f\"{pdb}_AB_receptor\"")
assert start < end, "could not bracket the preparation block"

NEW_PREP = '''    fixer.addMissingAtoms()

    # PDBFixer supplies missing heavy atoms only. Hydrogens and titration
    # states come from PDB2PQR with PROPKA, the route the course guide
    # recommends for receptors that will be docked with Vina.
    fixed = WORK / f"{pdb}_AB_fixed.pdb"
    with fixed.open("w") as fh:
        PDBFile.writeFile(fixer.topology, fixer.positions, fh, keepIds=True)

    prepared = WORK / f"{pdb}_AB_H.pdb"
    pqr = WORK / f"{pdb}_AB.pqr"
    run_tool(["pdb2pqr", "--ff=AMBER", "--ffout=AMBER",
              "--titration-state-method=propka", "--with-ph=%.1f" % PH,
              "--pdb-output", str(prepared), str(fixed), str(pqr)],
             f"pdb2pqr_{pdb}.log")
    assert prepared.exists() and prepared.stat().st_size > 10000, \\
        f"{pdb}: PDB2PQR produced no usable --pdb-output file"

    # Record every histidine's assigned state. HID carries the proton on ND1,
    # HIE on NE2, HIP on both and is positively charged.
    his_states = {}
    for line in prepared.read_text().splitlines():
        if line.startswith(("ATOM", "HETATM")):
            resname = line[17:20].strip()
            if resname in ("HID", "HIE", "HIP", "HIS"):
                his_states["%s:%s" % (line[21], line[22:26].strip())] = resname
    log("  %s: %d histidines, states %s"
        % (pdb, len(his_states), json.dumps(his_states, sort_keys=True)))

'''

src = src[:start] + NEW_PREP + src[end:]

# ------------------------------------------------------------- 2. manifest
old_return = '    return {"pdbqt": str(pdbqt), "atoms": int(len(coords)),'
assert src.count(old_return) == 1, "receptor return block not found"
src = src.replace(
    old_return,
    '    return {"pdbqt": str(pdbqt), "atoms": int(len(coords)),\n'
    '            "histidine_states": his_states,\n'
    '            "protonation": "PDB2PQR/PROPKA pH %.1f (AMBER naming)" % PH,')

# --------------------------------------------------- 3. provenance strings
src = src.replace(
    'manifest["receptor_composition"] = (\n'
    '        "Rigid A-B polymer only. Epibatidine, PAMs, lipids, waters, glycans "\n'
    '        "and ions excluded uniformly from all four receptors.")',
    'manifest["receptor_composition"] = (\n'
    '        "Rigid A-B polymer only. Epibatidine, PAMs, lipids, waters, glycans "\n'
    '        "and ions excluded uniformly from all four receptors.")\n'
    '    manifest["protonation_arm"] = (\n'
    '        "Arm 2: PDBFixer for missing heavy atoms; PDB2PQR with PROPKA at "\n'
    '        "pH 7.4 for hydrogens and titration states. Differs from arm 1 "\n'
    '        "only in protonation.")')

# ------------------------------------- 4. regression target does not apply
src = src.replace(
    'REGRESSION = {\n    "rank1_range": (6.40, 6.46),\n    "rank2_range": (0.70, 0.80),\n}',
    '# Arm 1 reproduced the Module 7 baseline exactly. Arm 2 deliberately\n'
    '# changes protonation, so the arm-1 window is a reference point rather\n'
    '# than a pass/fail gate: the run continues and the difference is reported.\n'
    'REGRESSION = {\n    "rank1_range": (6.40, 6.46),\n    "rank2_range": (0.70, 0.80),\n}')

src = src.replace(
    '        if not ok and not args.force:\n'
    '            log("STOP: regression check did not reproduce the Module 7 baseline.")\n'
    '            log("      The matrix was not run. Inspect regression_check.json.")\n'
    '            return\n',
    '        if not ok:\n'
    '            log("NOTE: arm 2 does not reproduce the arm-1 cognate numbers.")\n'
    '            log("      That is the expected consequence of changing protonation;")\n'
    '            log("      the difference is the result. Continuing.")\n')

TARGET.write_text(src)
print("PATCH3_OK bytes=%d" % len(src))

import py_compile
py_compile.compile(str(TARGET), doraise=True)
print("COMPILE_OK")
