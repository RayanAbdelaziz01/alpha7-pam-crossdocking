"""Patch 2 for matrix_runner.py.

Meeko's -d/--delete_residues and --delete_bad_res_from_box_radius both act
after the stage that fails, so neither can rescue a residue that cannot be
turned into an RDKit molecule in the first place. The only reliable remedy is
to remove the offending atoms from the PDB before Meeko reads it.

Two changes:

1. Strip OXT atoms from the PDBFixer output. OXT is a terminal carboxyl cap
   added by PDBFixer; it is absent from Meeko's internal-residue templates and
   is the proximate cause of the valence error. No OXT atom lies near the
   transmembrane PAM site, so removing them cannot affect docking.

2. In the receptor retry loop, physically delete the offending residue's atom
   records from the PDB instead of passing -d to Meeko. The existing distance
   guard is unchanged: a residue whose centre of mass lies within 8 A of the
   docking box still raises rather than being silently removed.
"""

import re
import sys
from pathlib import Path

TARGET = Path(sys.argv[1] if len(sys.argv) > 1 else "/content/matrix_runner.py")
src = TARGET.read_text()

# ---------------------------------------------------------------- change 1
anchor = '''    prepared = WORK / f"{pdb}_AB_H.pdb"
    with prepared.open("w") as fh:
        PDBFile.writeFile(fixer.topology, fixer.positions, fh, keepIds=True)
'''
assert src.count(anchor) == 1, "prepared-PDB write block not found"
strip_oxt = anchor + '''
    # PDBFixer caps chain termini with OXT, which is absent from Meeko's
    # internal-residue templates and triggers a valence error. No OXT atom is
    # anywhere near the transmembrane PAM site.
    _lines = prepared.read_text().splitlines(True)
    _kept = [l for l in _lines
             if not (l.startswith(("ATOM", "HETATM"))
                     and l[12:16].strip() == "OXT")]
    if len(_kept) != len(_lines):
        log(f"  {pdb}: removed {len(_lines) - len(_kept)} OXT cap atom(s)")
    prepared.write_text("".join(_kept))
'''
src = src.replace(anchor, strip_oxt)

# ---------------------------------------------------------------- change 2
old_args = '''        args = ["mk_prepare_receptor.py", "--read_pdb", prepared,
                "-o", prefix, "-p"]
        if dropped:
            args += ["-d", ",".join(dropped)]
'''
assert src.count(old_args) == 1, "meeko arg block not found"
new_args = '''        args = ["mk_prepare_receptor.py", "--read_pdb", prepared,
                "-o", prefix, "-p"]
'''
src = src.replace(old_args, new_args)

old_append = '''        log("  %s: residue %s unbuildable, %.1f A outside the box - deleting"
            % (pdb, key, distance))
        dropped.append(key)
'''
assert src.count(old_append) == 1, "drop-logging block not found"
new_append = '''        log("  %s: residue %s unbuildable, %.1f A outside the box - deleting"
            % (pdb, key, distance))
        _chain, _num = key.split(":", 1)
        _num = _num.strip()
        _lines = Path(prepared).read_text().splitlines(True)
        _kept = [l for l in _lines
                 if not (l.startswith(("ATOM", "HETATM"))
                         and l[21] == _chain and l[22:26].strip() == _num)]
        if len(_kept) == len(_lines):
            raise RuntimeError("%s: no atom records matched residue %s"
                               % (pdb, key))
        Path(prepared).write_text("".join(_kept))
        dropped.append(key)
'''
src = src.replace(old_append, new_append)

TARGET.write_text(src)
print("PATCH2_OK bytes=%d" % len(src))

import py_compile
py_compile.compile(str(TARGET), doraise=True)
print("COMPILE_OK")
