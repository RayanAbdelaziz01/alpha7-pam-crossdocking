"""Patch matrix_runner.py: tolerate unbuildable residues outside the docking box.

Meeko fails to build an RDKit molecule for some chain-terminal residues
(PDBFixer adds OXT, which does not match Meeko's internal-residue template).
Its own --delete_bad_res_from_box_radius option does not help, because the
failure happens during the initial residue-molecule build, before the
template-matching stage where that option applies.

This patch replaces the single Meeko receptor call with a retry loop that:
  1. reads the offending residue key out of Meeko's error text,
  2. measures that residue's centre of mass against the docking box,
  3. refuses to drop anything within 8 A of the box (a site residue),
  4. otherwise re-runs Meeko with that residue explicitly deleted,
  5. records every dropped residue in the manifest.
"""

import re
import sys
from pathlib import Path

TARGET = Path(sys.argv[1] if len(sys.argv) > 1 else "/content/matrix_runner.py")
src = TARGET.read_text()

HELPERS = '''
def run_tool_soft(args, log_name):
    """Run a tool without raising; return (returncode, combined output)."""
    args = [str(a) for a in args]
    args[0] = str(Path(sys.executable).parent / args[0])
    proc = subprocess.run(args, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, cwd=str(RUN_DIR))
    (WORK / log_name).write_text(proc.stdout)
    return proc.returncode, proc.stdout


def residue_com_distance_from_box(pdb_path, key):
    """Distance from a residue's centre of mass to the docking box region."""
    if ":" not in key:
        return None
    chain, num = key.split(":", 1)
    num = num.strip()
    rows = [l for l in open(pdb_path)
            if l.startswith(("ATOM", "HETATM"))
            and l[21] == chain and l[22:26].strip() == num]
    if not rows:
        return None
    xyz = np.array([[float(l[30:38]), float(l[38:46]), float(l[46:54])]
                    for l in rows])
    com = xyz.mean(axis=0)
    outside = np.maximum(
        np.abs(com - np.array(BOX["center"])) - np.array(BOX["size"]) / 2.0, 0.0)
    return float(np.linalg.norm(outside))


def meeko_receptor_with_retries(pdb, prepared, prefix, max_tries=12):
    """Prepare a receptor, dropping only unbuildable residues outside the box."""
    dropped = []
    for _ in range(max_tries):
        args = ["mk_prepare_receptor.py", "--read_pdb", prepared,
                "-o", prefix, "-p"]
        if dropped:
            args += ["-d", ",".join(dropped)]
        code, out = run_tool_soft(args, "meeko_receptor_%s.log" % pdb)
        if code == 0:
            if dropped:
                log("  %s: dropped %d residue(s) outside the box: %s"
                    % (pdb, len(dropped), ", ".join(dropped)))
            return dropped
        found = re.search(r"corresponding to key (\\S+)", out)
        if not found:
            print(out[-3000:], flush=True)
            raise RuntimeError(
                "%s: receptor preparation failed without a residue key" % pdb)
        key = found.group(1).strip().rstrip(".,")
        if key in dropped:
            raise RuntimeError("%s: residue %s still failing after deletion"
                               % (pdb, key))
        distance = residue_com_distance_from_box(prepared, key)
        if distance is None:
            raise RuntimeError("%s: cannot locate unbuildable residue %s"
                               % (pdb, key))
        if distance < 8.0:
            raise RuntimeError(
                "%s: unbuildable residue %s lies %.2f A from the docking box; "
                "refusing to silently drop a binding-site residue"
                % (pdb, key, distance))
        log("  %s: residue %s unbuildable, %.1f A outside the box - deleting"
            % (pdb, key, distance))
        dropped.append(key)
    raise RuntimeError("%s: too many unbuildable residues: %s" % (pdb, dropped))


'''

# 1. insert the helpers immediately before write_status
anchor = "def write_status(payload):"
assert src.count(anchor) == 1, "write_status anchor not found exactly once"
src = src.replace(anchor, HELPERS.lstrip("\n") + anchor)

# 2. make sure `re` is imported at module level
if not re.search(r"^import re$", src, flags=re.M):
    src = src.replace("import platform\n", "import platform\nimport re\n", 1)

# 3. replace the Meeko receptor invocation with the retry loop
pattern = re.compile(
    r"[ \t]*run_tool\(\[\"mk_prepare_receptor\.py\".*?\n(?:[^\n]*\n)?",
    re.S)
match = pattern.search(src)
assert match, "could not locate the mk_prepare_receptor call"
replacement = "    dropped_residues = meeko_receptor_with_retries(pdb, prepared, prefix)\n"
src = src[:match.start()] + replacement + src[match.end():]

# 4. record dropped residues in the manifest entry
old_return = '    return {"pdbqt": str(pdbqt), "atoms": int(len(coords)),'
assert src.count(old_return) == 1, "receptor return block not found"
src = src.replace(
    old_return,
    '    return {"pdbqt": str(pdbqt), "atoms": int(len(coords)),\n'
    '            "dropped_unbuildable_residues": dropped_residues,')

TARGET.write_text(src)
print("PATCH_OK bytes=%d" % len(src))

# sanity: the file must still compile
import py_compile
py_compile.compile(str(TARGET), doraise=True)
print("COMPILE_OK")
